"""Integration: MOCK vision → risk → alerts without YOLO."""

import numpy as np

from alerts.notify import NotificationService, NotifyConfig
from alerts.store import AlertStore
from ingest.sampler import SampledFrame
from pipeline import CyberEyePipeline, demo_synthetic_run
from vision.detector import Detection, VisionAdapter


def test_synthetic_demo_creates_alerts(tmp_path):
    store = AlertStore(tmp_path / "alerts.db")
    result = demo_synthetic_run(store, frames=16)
    assert result.backend == "mock"
    assert result.source_label == "Authorized Camera — Synthetic Demo"
    assert result.frames_processed == 16
    assert len(result.alerts_created) >= 1
    open_alerts = store.list_alerts(status="open")
    assert len(open_alerts) == len(result.alerts_created)
    categories = {a.category for a in result.alerts_created}
    assert categories & {
        "potential_fight",
        "potential_fall",
        "potential_weapon_object",
    }
    first = result.alerts_created[0]
    assert first.severity in {"warning", "critical", "info"}
    assert first.correlation_id
    assert first.delivery_status == "pending"
    ids = {a.correlation_id for a in result.alerts_created}
    assert len(ids) == 1
    predicted = {a.category for a in result.assessments}
    assert "game_or_play" in predicted
    assert "dance" in predicted
    assert "potential_fight" in predicted
    sports = {a.sport_context for a in result.assessments if a.sport_context}
    assert {"basketball", "soccer"} <= sports
    places = {a.place_type for a in result.assessments if a.place_type and a.place_type != "unknown"}
    assert {"basketball_court", "sports_field"} <= places or places  # MOCK stamps sports venues
    assert all("madison" not in (a.place_display or "").lower() for a in result.assessments)
    # Blank MOCK color-wash frames must not invent extra sports.
    assert sports <= {"basketball", "soccer"}
    assert all(a.face_cue_status == "disabled" for a in result.assessments)
    non_alerts = {a.category for a in result.assessments if not a.should_alert}
    assert "game_or_play" in non_alerts
    assert "dance" in non_alerts
    assert result.objects_backend == "mock"
    assert result.object_counts
    assert any(
        obj.get("id") == "refrigerator"
        for a in result.assessments
        for obj in a.objects_seen
    )


def test_synthetic_demo_offline_notify_does_not_invent_success(tmp_path):
    store = AlertStore(tmp_path / "alerts.db")
    store.add_recipient("op@example.com", created_by="test")
    notifier = NotificationService(
        store,
        NotifyConfig(resend_api_key="", email_recipients_env="op@example.com"),
    )
    result = demo_synthetic_run(store, frames=16, notifier=notifier)
    assert len(result.alerts_created) >= 1
    for alert in result.alerts_created:
        loaded = store.get(alert.id)
        assert loaded.delivery_status == "queued"
        assert loaded.delivery_status != "sent"


def test_blank_color_wash_does_not_invent_sport(tmp_path):
    from vision.assists import AssistState, enrich_detections

    img = np.zeros((120, 160, 3), dtype=np.uint8)
    img[:, :, 0] = 200
    img[:, :, 1] = 40
    img[:, :, 2] = 60
    dets, assist = enrich_detections(
        img,
        [Detection("person", 0.9, (10, 10, 40, 80))],
        AssistState(),
    )
    assert assist.sport_context is None
    assert all(not (d.extras or {}).get("sport_context") for d in dets)


class _OrdinaryAdapter(VisionAdapter):
    name = "ordinary-test"

    def detect(self, image_bgr, frame_index: int = 0):
        return [Detection("ordinary", 0.94)]


def test_ordinary_frames_are_counted_without_alerts(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "vision.object_inventory.try_load_yolo", lambda model_name="yolov8n.pt": None
    )
    store = AlertStore(tmp_path / "alerts.db")
    pipe = CyberEyePipeline(
        store=store,
        adapter=_OrdinaryAdapter(),
        snapshot_dir=tmp_path / "snaps",
        object_mode="auto",
    )
    frames = [
        SampledFrame(
            index=i,
            timestamp_sec=i / 2.0,
            image_bgr=np.zeros((8, 8, 3), dtype=np.uint8),
            source_label="authorized upload — clip.avi",
        )
        for i in range(5)
    ]
    result = pipe.run_frames(frames, source_label="authorized upload — clip.avi")
    assert result.frames_processed == 5
    assert result.alerts_created == []
    assert result.category_counts == {"ordinary": 5}
    assert store.list_alerts() == []
    assert result.objects_backend == "unavailable"
    assert result.object_counts == {}
    assert all(not a.objects_seen for a in result.assessments)
